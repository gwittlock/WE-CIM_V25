#ifndef _DWGREADER_H
#define _DWGREADER_H

#include "stdafx.h"
#include "DwgTypes.h"
#include "Return.h"
#include "DynamicArray.h"
#include "dwg_file.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class CSectionLocator;
class CObjectLocator;
class CClassMapper;
class CCommonEntityData;

class dllExport CDwgReader
{
public:

	CDwgReader( void );

	CReturn	Read( const CString& full_path );

	~CDwgReader( void );

private:

	CReturn VersionRead();
	CReturn SectionTableRead();
	CReturn DrawingObjectsRead();
	CReturn ClassSectionRead();
	CReturn	ObjectMapRead();
	CReturn ObjectRead( int objHandle, short objType, long objSize );
	CReturn ReadCommonEntityData( CCommonEntityData* ced );

	CReturn ReadLayer( const CCommonEntityData& ced );
	CReturn ReadLine( const CCommonEntityData& ced );
	CReturn ReadArc( const CCommonEntityData& ced );
	CReturn ReadCircle( const CCommonEntityData& ced );
	CReturn ReadPoly2d( const CCommonEntityData& ced );
	CReturn ReadPoly3d( const CCommonEntityData& ced );
	CReturn ReadVertex3d( const CCommonEntityData& ced );

	int		ReadHandleReference();
	void	ReadExtendedEntityData();
	void	ReadGraphicsData();

	long	ReadCommonEntityHandleData( const CCommonEntityData& ced );

	CString	ReadString();

	BOOL	MustProcess( short objType );
	char*	ObjectString( short objType );

	short	ObjectTypeConvert( short objType );

	void DumpObjectTable();

private:

	CDWGFile	m_file;
	int			m_version;
	BOOL		m_dump;

	CDynamicArray<CSectionLocator*>	m_sections;
	CDynamicArray<CObjectLocator*>	m_objects;
	CDynamicArray<CClassMapper*>	m_classes;
};

#endif