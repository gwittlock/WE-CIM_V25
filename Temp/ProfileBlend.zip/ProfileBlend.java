
// mac.rad|dbl|Radius|1.0

import Weng.System.*;
import Weng.Geometry.*;
import Weng.Modeler.*;
import Weng.Math.UnitVec2d;


public class ProfileBlend implements WengMacro
{
	// This method is called via the Regenerate button.
	public void main()
	{
		double VECTOR_TOL = 1.e-6;
		double rad = Model.DoubleGet("mac.rad");
		
		try
		{
			DbProfile dbProfile = Model.ProfileGet("target");
			int count = dbProfile.Count();
			
			if (count > 1)
			{
				boolean isClosed = dbProfile.IsClosed();
				
				for (int indx = 0; indx < count; ++indx)
				{
					int jndx = indx + 1;
					if ((jndx >= count) && isClosed)
						jndx = 0;  // fencepost condition, profile end --> profile start
					
					DbCurve dbCurveA = DbCurve.DbCurve( dbProfile.Get(indx) );
					DbCurve dbCurveB = DbCurve.DbCurve( dbProfile.Get(jndx) );
					
					UnitVec2d tanA = dbCurveA.EndTan();
					UnitVec2d tanB = dbCurveB.StartTan();
					
					double cross = (tanA.X() * tanB.Y()) - (tanA.Y() * tanB.X());
					if (Math.abs(cross) < VECTOR_TOL)
					{
						// Nothing to do because the curves meet tangentially.
					}
					else
					{
						int dir = ((cross > 0) ? Const.CCW : Const.CW);
						DbArc blend = Editor.Blend(dbCurveA, dbCurveB, rad, dir, Const.SMALL);
						if (blend != null)
						{
							++count;  // a curve was added to the profile
							++indx;   // we can skip the blend because it's tangent to the next curve
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			ExceptionPrinter.StackTracePrint( e );
		}
	}
}

