#ifndef _DWGREADER_H
#define _DWGREADER_H

#include "stdafx.h"
#include "DwgTypes.h"
#include "Return.h"
#include "DynamicArray.h"
#include "dwg_file.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class CSectionLocator;
class CObjectLocator;


class dllExport CDwgReader
{
public:

	CDwgReader( void );

	CReturn	Read( const CString& full_path );

	~CDwgReader( void );

private:

	CReturn VersionRead();
	CReturn SectionTableRead();
	CReturn DrawingObjectsRead();
	CReturn	ObjectMapRead();
	CReturn ObjectRead( long objSize, short objType );
	CReturn CommonEntityDataRead();

	CReturn ReadLayer( long objSize );
	CReturn ReadLine( long objSize );
	CReturn ReadArc( long objSize );
	CReturn ReadCircle( long objSize );

	BOOL MustProcess( short objType );
	char* ObjectString( short objType );

private:

	CDWGFile	m_file;
	int			m_version;
	BOOL		m_dump;

	CDynamicArray<CSectionLocator*>	m_sections;
	CDynamicArray<CObjectLocator*>	m_objects;
};

#endif