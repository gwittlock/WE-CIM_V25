
#include "DwgReader.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

CDwgReader::CDwgReader()
{
	m_section_count = 0;
}

CDwgReader::~CDwgReader()
{
}

CReturn
CDwgReader::Read( const CString& full_path )
{
	CReturn status;

	status = m_file.Open( full_path, FILEMODE_READ );

	if ( status.IsOk() )
		status = SectionTableRead();

	if ( status.IsOk() )
		status = ObjectMapRead();

	m_file.Close();

#if OKAY
	int count;
	INT32 offset;
	INT32 objSize;
	unsigned char bitShort;
	unsigned char objType;

	R2000_read_section_table();

	offset = g_sections[2].start + 1;
	lseek( m_file, offset, SEEK_SET );

	count = read( m_file, &objSize, sizeof( MODULAR_SHORT ) );
	offset += count;

	count = read( m_file, &bitShort, sizeof( unsigned char ) );
	offset += count;

	count = read( m_file, &objType, sizeof( unsigned char ) );
	offset += count;

	lseek( __drawing->source_file, 0L, SEEK_SET );
	read_in_file();

	R2000_read_objects();

	close( m_file );
#endif

	return status;
}

CReturn
CDwgReader::SectionTableRead()
{
	CReturn status;

	char version[8];
	int indx;

	m_file.Seek( 0L, CFile::begin );

	m_file.Read( (BYTE*) version, 8 );

	m_file.Seek( 0x15, CFile::begin );

	m_section_count = m_file.ReadINT32();;

	for (indx = 0; indx < m_section_count; ++indx)
	{
		m_sections[indx].recno = m_file.ReadBYTE();
		m_sections[indx].start = m_file.ReadINT32();
		m_sections[indx].size  = m_file.ReadINT32();
	}

	return status;
}

CReturn
CDwgReader::DrawingObjectsRead( LONG offset )
{
	CReturn status;
	
	long objSize;
	short objType;
	BYTE foo;

	m_file.Seek( offset, CFile::begin );

	objSize = m_file.ReadModularShort();
	objType = m_file.ReadBitShort();

	return status;
}

CReturn
CDwgReader::ObjectMapRead()
{
	CReturn status;

	m_file.Seek( m_sections[2].start, CFile::begin );

	int objHandle = 0;
	long objOffset = 0L;

	short sectionSize = m_file.ReadINT16(true);
	while (TRUE)
	{
		objHandle += m_file.ReadModularChar();
		objOffset += m_file.ReadModularChar();
	}

	return status;
}