#ifndef _DWGREADER_H
#define _DWGREADER_H

#include "stdafx.h"
#include "types.h"
#include "Return.h"
#include "dwg_file.h"

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

typedef struct 
{
	UINT8 recno;
	INT32 start;
	INT32 size;
} tSections;


class dllExport CDwgReader
{
public:

	CDwgReader( void );

	CReturn	Read( const CString& full_path );

	~CDwgReader( void );

private:

	CReturn SectionTableRead();
	CReturn DrawingObjectsRead( LONG offset );
	CReturn	ObjectMapRead();

private:

	CDWGFile	m_file;
	tSections	m_sections[10];
	INT32		m_section_count;
};

#endif