﻿Imports FabV25_WIN8
Imports FabV25_WIN8.AppData

Public Module modView
    Public _pnlPicModelerHandle As IntPtr
    Public _pnlPicModelerGraphics As Graphics

    Public Structure ViewTransform
        Public Scale As Double
        Public OffsetX As Double
        Public OffsetY As Double
    End Structure

    Public Sub RedrawAll()
        frmMain.pnlPicmodeler.Invalidate()
    End Sub

End Module
