VERSION 5.00
Begin VB.Form frmClock 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00E0E0E0&
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "DXF Clock"
   ClientHeight    =   4005
   ClientLeft      =   45
   ClientTop       =   570
   ClientWidth     =   4005
   BeginProperty Font 
      Name            =   "Times New Roman"
      Size            =   12
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   267
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   267
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.Timer Timer1 
      Interval        =   900
      Left            =   7920
      Top             =   7920
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuSaveAs 
         Caption         =   "Save as DXF"
      End
      Begin VB.Menu Hyphen1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "Exit"
      End
   End
End
Attribute VB_Name = "frmClock"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private MyPoints As My_Points
Private Sub mnuExit_Click()
    Unload Me
    End
End Sub
Private Sub mnuSaveAs_Click()
'Calls to the function in the module that creates a DXF file
    MainOutput Now, App.Path & "\ClockFace.dxf"
End Sub
Private Sub Form_Load()
'Stores the center points of the screen to memory
    MyPoints.X = Me.ScaleWidth * 0.5
    MyPoints.Y = Me.ScaleHeight * 0.5
End Sub
Private Sub PrintDate(ByVal iDate As String)
    CurrentX = MyPoints.X - (Len(iDate) * 3.75)
    CurrentY = MyPoints.Y + 60
    Print iDate
End Sub
Private Sub timer1_Timer()
Dim StartTime As Variant
Dim iDate As String, iHr As Integer, iMin As Integer, iSec As Integer
'Get the time
    StartTime = Now
'Get the date
    iDate = Format(StartTime, "dddd, mmmm d yyyy")
'Get the hours
    iHr = IIf(Hour(StartTime) > 12, Hour(StartTime) - 12, Hour(StartTime))
'Get the minutes
    iMin = Minute(StartTime)
'Get the seconds
    iSec = Second(StartTime)
'Clear the screen
    Cls
'Print the date
    PrintDate iDate
'Draw the hour hand
    DrawHand (Radians(30 * iHr)) + ((Radians(6 * iMin)) / 12), 60
'Draw the minute hand
    DrawHand (Radians(6 * iMin)) + ((Radians(6 * iSec)) / 60), 100
'Draw the seconds hand
    DrawHand Radians(6 * iSec), 125
End Sub
Private Sub DrawHand(ByVal iRadians As Single, ByVal i As Integer)
Dim X(1) As Integer, Y(1) As Integer
'Finds the outer x & y locations of the clock hands
    X(0) = MyPoints.X + (i * (Sin(iRadians)))
    Y(0) = MyPoints.Y - (i * (Cos(iRadians)))
'Finds the inner x & y locations of the clock hands
    X(1) = MyPoints.X - ((i * 0.25) * (Sin(iRadians)))
    Y(1) = MyPoints.Y + ((i * 0.25) * (Cos(iRadians)))
'Draw the line with an arrow head
        Line (X(0), Y(0))-(X(1), Y(1))
        ArrowHead iRadians, X(0), Y(0)
End Sub
Private Sub ArrowHead(iRadians As Single, sngX As Integer, sngY As Integer)
Dim X(1) As Integer, Y(1) As Integer
'The number "15" is the length in pixels of the arrow head
'Adding or subtracting 170 degrees from the angle of the
'clock hand gives us a 10 degree angle on the arrow head.
    'Finds the first side of the arrow head
        X(0) = sngX + (15 * (Sin(iRadians + Radians(170))))
        Y(0) = sngY - (15 * (Cos(iRadians + Radians(170))))
    'Finds the second side of the arrow head
        X(1) = sngX + (15 * (Sin(iRadians - Radians(170))))
        Y(1) = sngY - (15 * (Cos(iRadians - Radians(170))))
    'Draw the first side of the arrow head
        Line (sngX, sngY)-(X(0), Y(0))
    'Draw the second side of the arrow head
        Line (sngX, sngY)-(X(1), Y(1))
    'Draw the bottom side of the arrow head
        Line (X(0), Y(0))-(X(1), Y(1))
End Sub
