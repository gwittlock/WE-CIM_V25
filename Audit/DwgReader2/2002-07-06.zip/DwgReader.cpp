
#include "DwgReader.h"

void dumpDoubles( double* val, int count );

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class CSectionLocator
{
public:

	CSectionLocator( UINT8 recno, INT32 start, INT32 size )
	{
		m_recno = recno;
		m_start = start;
		m_size  = size;
	}

	UINT8 RecNo()	{ return m_recno; }
	INT32 Start()	{ return m_start; }
	INT32 Size()	{ return m_size; }

private:

	UINT8 m_recno;
	INT32 m_start;
	INT32 m_size;
};

class CObjectLocator
{
public:

	CObjectLocator( int objHandle, long objOffset )
	{
		m_objHandle = objHandle;
		m_objOffset = objOffset;
	}

	INT16 Handle()	{ return m_objHandle; }
	INT32 Offset()	{ return m_objOffset; }

private:

	int m_objHandle;
	long m_objOffset;
};

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

CDwgReader::CDwgReader()
	: m_version( 0 ),
	  m_dump( FALSE )
{
}

CDwgReader::~CDwgReader()
{
	m_sections.DestructiveFlush();
	m_objects.DestructiveFlush();
}

CReturn
CDwgReader::Read( const CString& full_path )
{
	CReturn status;

	status = m_file.Open( full_path, FILEMODE_READ );

	if ( status.IsOk() )
		status = VersionRead();

	if ( status.IsOk() )
		status = SectionTableRead();

	if ( status.IsOk() )
		status = ObjectMapRead();

	if ( status.IsOk() )
		status = DrawingObjectsRead();

	m_file.Close();

	return status;
}

CReturn
CDwgReader::Test( BYTE* bytes, int nbytes )
{
	CReturn status;

	short bs;

	m_file.TestBufferSet( bytes, nbytes );

	bs = m_file.ReadBitShort();

	return status;
}

CReturn
CDwgReader::VersionRead()
{
	CReturn status;
	char version[8];

	m_file.Seek( 0L, CFile::begin );
	m_file.ReadBytes( (BYTE*) version, 8 );

	if (stricmp( version, "AC1013" ) == 0)
		m_version = 13;
	else if (stricmp( version, "AC1014" ) == 0)
		m_version = 14;
	else if (stricmp( version, "AC1015" ) == 0)
		m_version = 15;
	else
		status.Internal( IDS_INTERNAL_ERROR, "CDwgReader::VersionRead() -- Unrecognized file tpye." );

	return status;
}

CReturn
CDwgReader::SectionTableRead()
{
	CReturn status;

	int		section_count;
	int		indx;
	UINT8	recno;
	INT32	start;
	INT32	size;

	m_file.Seek( 0x15, CFile::begin );

	section_count = m_file.ReadINT32();;

	for (indx = 0; indx < section_count; ++indx)
	{
		recno = m_file.ReadBYTE();
		start = m_file.ReadINT32();
		size  = m_file.ReadINT32();

		m_sections.Append( new CSectionLocator( recno, start, size ) );
	}

	return status;
}

CReturn
CDwgReader::DrawingObjectsRead()
{
	CReturn status;
	
	int count, indx;
	long objSize;
	short objType;

	count = m_objects.Count();
	for (indx = 0; indx < count; ++indx)
	{
		m_file.Seek( m_objects[indx]->Offset(), CFile::begin );

		objSize = m_file.ReadModularShort();
		objType = m_file.ReadBitShort();

		if ( MustProcess( objType ) )
		{
			if ( m_dump )
			{
				m_file.Seek( m_objects[indx]->Offset(), CFile::begin );
				dump( objSize );
			}
			else
			{
				ObjectRead( objSize, objType );
			}
		}
	}

	return status;
}

CReturn
CDwgReader::ObjectMapRead()
{
	CReturn status;

	INT16 CRC;

	m_file.Seek( m_sections[2]->Start(), CFile::begin );

	int objHandle = 0;
	long objOffset = 0L;

	while (TRUE)
	{
		short sectionSize = m_file.ReadINT16(true);
		if (sectionSize == 2)
		{ break; }

		while (sectionSize > 2)
		{
			objHandle += m_file.ReadModularChar();
			sectionSize -= m_file.Used();

			objOffset += m_file.ReadModularChar();
			sectionSize -= m_file.Used();

			m_objects.Append( new CObjectLocator( objHandle, objOffset ) );
		}

		CRC = m_file.ReadINT16(false);
	}

	return status;
}

CReturn
CDwgReader::ObjectRead( long objSize, short objType )
{
	CReturn status;

	char* type = ObjectString( objType );  // for debugging

	status = CommonEntityDataRead();

	if ( status.IsOk() )
	{
		switch( objType )
		{
		case DWG_VERTEX_2D:
			break;
		case DWG_VERTEX_3D:
			break;
		case DWG_VERTEX_MESH:
			break;
		case DWG_VERTEX_PFACE:
			break;
		case DWG_VERTEX_FACE:
			break;
		case DWG_POLYLINE_2D:
			break;
		case DWG_POLYLINE_3D:
			break;
		case DWG_ARC:
			break;
		case DWG_CIRCLE:
			break;
		case DWG_LINE:
			status = ReadLine();
			break;
		case DWG_POINT:
			break;
		case DWG_LAYER:
			status = ReadLayer();
			break;
		}
	}

	return status;
}

CReturn
CDwgReader::CommonEntityDataRead()
{
	CReturn status;

	BYTE	fodder[1024];
	BYTE	byte;
	double	lineTypeScale;
	long	size;
	int		code;
	int		count;
	int		color;
	int		invisible;
	int		lineTypeFlags;
	int		plotStyleFlags;
	int		lineWeightFlag;

	// The following two data items are handled by the caller.
	// MS	size of object (not including CRC)
	// BS	object type

	if (m_version == 15)
	{
		// object size in bits
		size = m_file.ReadRawLong();
	}

	// objects handle
	byte = m_file.ReadBYTE();
	code = (int) ((byte & 0xf0) >> 4);
	count = (int) (byte & 0x0f);
	m_file.ReadBytes( fodder, count );

	// extended entity data size
	size = m_file.ReadBitShort();
	if (size > 0)
	{
		// TODO: need method to skip ahead N-bytes
		// X	extended entity data
		m_file.ReadBytes( fodder, size );
	}

	// graphics present flag
	if ( m_file.ReadBit() )
	{
		// size of graphics image
		size = m_file.ReadRawLong();

		// TODO: need method to skip ahead N-bytes
		// the graphics image
		m_file.ReadBytes( fodder, size );
	}

	if (m_version == 13 || m_version == 14)
	{
		// object size in bits
		size = m_file.ReadRawLong();

		// flags
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();

		// common parameters
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();
		m_file.ReadBit();
	}

	if (m_version == 15)
	{
		// 0 if the previous and next linkers are present.
		// 1 if the are both defaults (1 back and 1 forward).
		byte = m_file.ReadBit();

		// Entity color
		color = m_file.ReadBitShort();
		
		// line type scale
		lineTypeScale = m_file.ReadBitDouble();

		// line type flags
		lineTypeFlags = m_file.ReadCode();

		// plot style flags
		plotStyleFlags = m_file.ReadCode();

		// invisible flag
		invisible = m_file.ReadBitShort();

		// entity line weight flag
		lineWeightFlag = m_file.ReadRawShort();
	}

	// X	object data (varies with object type) (called by next method af this one)
	// X	handles associated with this object.
	// RS	CRC

	return status;
}

CReturn
CDwgReader::ReadLayer()
{
	CReturn status;

	BYTE	fodder[1024];
	BYTE	byte;
	double	lineTypeScale;
	long	size;
	int		code;
	int		count;
	int		color;
	int		invisible;
	int		lineTypeFlags;
	int		plotStyleFlags;
	int		lineWeightFlag;

	// The following two data items are handled by the caller.
	// MS	size of object (not including CRC)
	// BS	object type

	if (m_version == 15)
	{
		// object size in bits
		size = m_file.ReadRawLong();
	}

	// objects handle
	byte = m_file.ReadBYTE();
	code = (int) ((byte & 0xf0) >> 4);
	count = (int) (byte & 0x0f);
	m_file.ReadBytes( fodder, count );

	return status;
}

/*
LINE (19)
	Common Entity Data
R13-R14 Only:
	Start pt	3BD	10
	End   pt	3BD	11
R2000 Only:
	Z's are zero bit	B	
	Start Point x	RD	10
	End Point x	DD	11	Use 10 value for default
	Start Point y	RD	20
	End Point y	DD	21	Use 20 value for default
	Start Point z	RD	30	Present only if "Z's are zero bit" is 0
	End Point z	DD	31	Present only if "Z's are zero bit" is 0, use 30 value for default.

Common:
	Thickness	BT	39
	Extrusion	BE	210
	Common Entity Handle Data
	CRC	X	---
*/
CReturn
CDwgReader::ReadLine()
{
	CReturn status;

	double xs, ys, zs;
	double xe, ye, ze;
	double extrusion[3];
	BOOL zZeroBit;

	// Common Entity Data (handled by caller)

	if (m_version == 13 || m_version == 14)
	{
		xs = m_file.ReadBitDouble();
		ys = m_file.ReadBitDouble();
		zs = m_file.ReadBitDouble();

		xe = m_file.ReadBitDouble();
		ye = m_file.ReadBitDouble();
		ze = m_file.ReadBitDouble();
	}

	if (m_version == 15)
	{
		zZeroBit = m_file.ReadBit();

		xs = m_file.ReadRawDouble();
		xe = m_file.ReadBitDoubleDef( xs );

		ys = m_file.ReadRawDouble();
		ye = m_file.ReadBitDoubleDef( ys );

		if ( zZeroBit )
		{
			zs = 0.;
			ze = 0.;
		}
		else
		{
			zs = m_file.ReadRawDouble();
			ze = m_file.ReadBitDoubleDef( zs );
		}
	}

	m_file.ReadBitThickess();
	m_file.ReadBitExtrusion( extrusion );

	// H	Common Entity Handle Data
	// X	CRC

	return status;
}

// NOTE: The switch statement should match that in CDwgReader::ObjectRead()
BOOL
CDwgReader::MustProcess( short objType )
{
	char* type = ObjectString( objType );  // for debugging

	switch( objType )
	{
	case DWG_VERTEX_2D:
	case DWG_VERTEX_3D:
	case DWG_VERTEX_MESH:
	case DWG_VERTEX_PFACE:
	case DWG_VERTEX_FACE:
	case DWG_POLYLINE_2D:
	case DWG_POLYLINE_3D:
	case DWG_ARC:
	case DWG_CIRCLE:
	case DWG_LINE:
	case DWG_POINT:
	case DWG_LAYER:
		return TRUE;
	default:
		return FALSE;
	}
}

char*
CDwgReader::ObjectString( short objType )
{
	switch( objType )
	{
	case DWG_UNUSED:				return "DWG_UNUSED";
	case DWG_TEXT:					return "DWG_TEXT";
	case DWG_ATTRIB:				return "DWG_ATTRIB";
	case DWG_ATTDEF:				return "DWG_ATTDEF";
	case DWG_BLOCK:					return "DWG_BLOCK";
	case DWG_ENDBLK:				return "DWG_ENDBLK";
	case DWG_SEQEND:				return "DWG_SEQEND";
	case DWG_INSERT:				return "DWG_INSERT";
	case DWG_MINSERT:				return "DWG_MINSERT";
	case DWG_0x09:					return "DWG_0x09";
	case DWG_VERTEX_2D:				return "DWG_VERTEX_2D";
	case DWG_VERTEX_3D:				return "DWG_VERTEX_3D";
	case DWG_VERTEX_MESH:			return "DWG_VERTEX_MESH";
	case DWG_VERTEX_PFACE:			return "DWG_VERTEX_PFACE";
	case DWG_VERTEX_FACE:			return "DWG_VERTEX_FACE";
	case DWG_POLYLINE_2D:			return "DWG_POLYLINE_2D";
	case DWG_POLYLINE_3D:			return "DWG_POLYLINE_3D";
	case DWG_ARC:					return "DWG_ARC";
	case DWG_CIRCLE:				return "DWG_CIRCLE";
	case DWG_LINE:					return "DWG_LINE";
	case DWG_DIM_ORDINATE:			return "DWG_DIM_ORDINATE";
	case DWG_DIM_LINEAR:			return "DWG_DIM_LINEAR";
	case DWG_DIM_ALIGNED:			return "DWG_DIM_ALIGNED";
	case DWG_DIM_ANG_3PT:			return "DWG_DIM_ANG_3PT";
	case DWG_DIM_ANG_2LN:			return "DWG_DIM_ANG_2LN";
	case DWG_DIM_RADIUS:			return "DWG_DIM_RADIUS";
	case DWG_DIM_DIAMETER:			return "DWG_DIM_DIAMETER";
	case DWG_POINT:					return "DWG_POINT";
	case DWG_3DFACE:				return "DWG_3DFACE";
	case DWG_POLYLINE_PFACE:		return "DWG_POLYLINE_PFACE";
	case DWG_POLYLINE_MESH:			return "DWG_POLYLINE_MESH";
	case DWG_SOLID:					return "DWG_SOLID";
	case DWG_TRACE:					return "DWG_TRACE";
	case DWG_SHAPE:					return "DWG_SHAPE";
	case DWG_VIEWPORT: 				return "DWG_VIEWPORT";
	case DWG_ELLIPSE:				return "DWG_ELLIPSE";
	case DWG_SPLINE: 				return "DWG_SPLINE";
	case DWG_REGION:				return "DWG_REGION";
	case DWG_3DSOLID:				return "DWG_3DSOLID";
	case DWG_BODY:					return "DWG_BODY";
	case DWG_RAY:					return "DWG_RAY";
	case DWG_XLINE:					return "DWG_XLINE";
	case DWG_DICTIONARY:			return "DWG_DICTIONARY";
	case DWG_0x2B:					return "DWG_0x2B";
	case DWG_MTEXT:					return "DWG_MTEXT";
	case DWG_LEADER:				return "DWG_LEADER";
	case DWG_TOLERANCE:				return "DWG_TOLERANCE";
	case DWG_MLINE:					return "DWG_MLINE";
	case DWG_BLOCK_CTRL_OBJ:		return "DWG_BLOCK_CTRL_OBJ";
	case DWG_BLOCK_HEADER:			return "DWG_BLOCK_HEADER";
	case DWG_LAYER_CTRL_OBJ:		return "DWG_LAYER_CTRL_OBJ";
	case DWG_LAYER:					return "DWG_LAYER";
	case DWG_STYLE_CTRL_OBJ:		return "DWG_STYLE_CTRL_OBJ";
	case DWG_STYLE:					return "DWG_STYLE";
	case DWG_0x36:					return "DWG_0x36";
	case DWG_0x37:					return "DWG_0x37";
	case DWG_LTYPE_CTRL_OBJ:		return "DWG_LTYPE_CTRL_OBJ";
	case DWG_LTYPE:					return "DWG_LTYPE";
	case DWG_0x3A:					return "DWG_0x3A";
	case DWG_0x3B:					return "DWG_0x3B";
	case DWG_VIEW_CTRL_OBJ:			return "DWG_VIEW_CTRL_OBJ";
	case DWG_VIEW:					return "DWG_VIEW";
	case DWG_UCS_CTRL_OBJ:			return "DWG_UCS_CTRL_OBJ";
	case DWG_UCS:					return "DWG_UCS";
	case DWG_VPORT_CTRL_OBJ:		return "DWG_VPORT_CTRL_OBJ";
	case DWG_VPORT:					return "DWG_VPORT";
	case DWG_APPID_CTRL_OBJ:		return "DWG_APPID_CTRL_OBJ";
	case DWG_APPID:					return "DWG_APPID";
	case DWG_DIMSTYLE_CTRL_OBJ:		return "DWG_DIMSTYLE_CTRL_OBJ";
	case DWG_DIMSTYLE:				return "DWG_DIMSTYLE";
	case DWG_VP_ENT_HDR_CTRL_OBJ:	return "DWG_VP_ENT_HDR_CTRL_OBJ";
	case DWG_VP_ENT_HDR:			return "DWG_VP_ENT_HDR";
	case DWG_GROUP:					return "DWG_GROUP";
	case DWG_MLINESTYLE:			return "DWG_MLINESTYLE";
	default:						return "UNKNOWN";
	}
}

void
CDwgReader::dump( long objSize )
{
	FILE* f;
	BYTE bytes[1024];
	BYTE byte;
	long indx;
	double val[10];
	int count;

	m_file.ReadBytes( bytes, objSize );

	//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

	f = fopen( "c:\\_Weng\\DwgReader2\\_binary.txt", "wb" );
	if (f != NULL)
	{
		fwrite( bytes, sizeof( BYTE ), objSize, f );
		fflush( f );
	}
	fclose( f );

	//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

	f = fopen( "c:\\_Weng\\DwgReader2\\_bits.txt", "w" );
	if (f != NULL)
	{
		for (indx = 0; indx < objSize; ++indx)
		{
			byte = bytes[indx];

			fprintf( f, "%d", ((byte & 0x80) ? 1 : 0) );
			fprintf( f, "%d", ((byte & 0x40) ? 1 : 0) );
			fprintf( f, "%d", ((byte & 0x20) ? 1 : 0) );
			fprintf( f, "%d", ((byte & 0x10) ? 1 : 0) );
			fprintf( f, " " );
			fprintf( f, "%d", ((byte & 0x08) ? 1 : 0) );
			fprintf( f, "%d", ((byte & 0x04) ? 1 : 0) );
			fprintf( f, "%d", ((byte & 0x02) ? 1 : 0) );
			fprintf( f, "%d", ((byte & 0x01) ? 1 : 0) );
			fprintf( f, " " );

			if (((indx + 1) % 8) == 0)
				fprintf( f, "\n\n" );
		}
		fflush( f );
	}
	fclose( f );

	//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

	count = 8;
	val[0] = 1.0;
	val[1] = 2.0;
	val[2] = 3.0;
	val[3] = 4.0;
	val[4] = 5.0;
	val[5] = 6.0;
	val[6] = 10.0;
	val[7] = -1.0;

	dumpDoubles( val, count );
}

void
dumpDoubles( double* val, int count )
{
	FILE* f;
	char* ptr;
	int indx, jndx;

	f = fopen( "c:\\_Weng\\DwgReader2\\_vals.txt", "w" );
	if (f != NULL)
	{
		for (indx = 0; indx < count; ++indx)
		{
			ptr = (char*) &(val[indx]);

			fprintf( f, "\n\n" );
			fprintf( f, "val: %-10.6f\n\n", val[indx] );

			for (jndx = 0; jndx < sizeof( double ); ++jndx)
			{
				fprintf( f, "%d", (((*ptr) & 0x80) ? 1 : 0) );
				fprintf( f, "%d", (((*ptr) & 0x40) ? 1 : 0) );
				fprintf( f, "%d", (((*ptr) & 0x20) ? 1 : 0) );
				fprintf( f, "%d", (((*ptr) & 0x10) ? 1 : 0) );
				fprintf( f, " " );
				fprintf( f, "%d", (((*ptr) & 0x08) ? 1 : 0) );
				fprintf( f, "%d", (((*ptr) & 0x04) ? 1 : 0) );
				fprintf( f, "%d", (((*ptr) & 0x02) ? 1 : 0) );
				fprintf( f, "%d", (((*ptr) & 0x01) ? 1 : 0) );
				fprintf( f, " " );

				++ptr;
			}
		}
		fflush( f );
	}
	fclose( f );
}

